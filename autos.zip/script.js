const autosContainer = document.getElementById('autos-container');
const agregarBtn = document.getElementById('agregar');

let autos = [
  {
    nombre: "BMW M3",
    modelo: "E36 1994",
    descripcion: "Un clásico deportivo de los 90, conocido por su rendimiento y estilo icónico.",
    imagen: "https://upload.wikimedia.org/wikipedia/commons/5/55/BMW_M3_E36_Coupe.jpg"
  }
];

function mostrarAutos() {
  autosContainer.innerHTML = "";
  autos.forEach(auto => {
    const card = document.createElement('div');
    card.classList.add('auto-card');
    card.innerHTML = `
      <img src="${auto.imagen}" alt="${auto.nombre}">
      <h3>${auto.nombre}</h3>
      <p><strong>Modelo:</strong> ${auto.modelo}</p>
      <p>${auto.descripcion}</p>
    `;
    autosContainer.appendChild(card);
  });
}

agregarBtn.addEventListener('click', () => {
  const nombre = document.getElementById('nombre').value;
  const modelo = document.getElementById('modelo').value;
  const descripcion = document.getElementById('descripcion').value;
  const imagen = document.getElementById('imagen').value;

  if(nombre && modelo && descripcion && imagen) {
    autos.push({ nombre, modelo, descripcion, imagen });
    mostrarAutos();
  }
});

mostrarAutos();